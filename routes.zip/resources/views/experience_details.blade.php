
@extends('layouts.master2')
@section('main_content')
<?php 
$section_name='Work';
?>
{{-- @include('_next_url')  --}}
    

  <div class="page-content container container-plus">
    <div class="page-header pb-2">
      <h1 class="page-title text-primary-d2 text-150">
        Update your Experience       
      </h1>
    </div>


    <div class="row mt-2 mt-lg-4 pt-2">
      <div class="col-12 col-lg-6">
        <div class="card bcard h-100">
          <div class="border-t-3 w-100 brc-info-m1 radius-t-1"></div><!-- the colored line on top of stats -->

          <div class="card-header"> 
            <input type="text" onkeyup="search()" id="searchKeyword"    placeholder="Search recommended phrases by job title" required class="form-control form-control-lg shadow-none" id="id-form-field-2"> 
            
        </div>
        <div class="card-header">              
            <input type="text" onkeyup="search2()" id="searchKeyword2"    placeholder="Search by action word" required class="form-control form-control-lg shadow-none" id="id-form-field-2"> 

            <select name="tense" id="word_tense" required="" class="form-control" id="form-field-select-1" style="height: 46px; margin-left:20px;">                 
              <option value="">Select word tense</option>    
              <option value="present_word">Present Word</option>    
              <option value="past_word">Past Word</option>    
            </select>   
        </div>
        <div class="card-header">              
           <p style="display: block">Filter By Soft Skills</p>
            <select name="soft_skill" id="soft_skill" required="" class="form-control" id="form-field-select-1" style="height: 46px; margin-left:20px; float:left; width:60%">                 
              <option value="">Filter By Soft Skills</option>    
            <?php 
              $collection = DB::table('data_experiences')
                            ->select('soft_skill')
                            ->distinct()
                            ->get();
            ?>
             @foreach ($collection as $item)                  
             <option value="{{$item->soft_skill}}">{{$item->soft_skill}}</option>
             @endforeach    
            </select>   
        </div>
        {{-- <p>Total Data : <span id="total_records"></span></p> --}}
        <div class="card-body  d-flex flex-column1 justify-content-center py-2 py-md-3 px-0 px-md-4">            
          <div class="default_task_area" id="task_area" style="width: 100%; height: 400px; overflow-y: scroll;">              
          </div> 
        </div>

      </div>
    </div>

      <div class="col-12 col-lg-6">

        <div class="card border-0 shadow-sm">
          <div class="card-header bgc-default-d2">
            <h3 class="card-title text-white text-130">
              Your selected experiences
            </h3>
          </div>
          <div class="card bcard border-1 brc-dark-l1">
            <div class="card-body p-0">              
              <form action="updateExperienceDescription" id="descForm" method="post">
                @csrf 
                <textarea id="summernote" name="description"></textarea>               
              </form>        
            </div>

            <div class="mt-5 border-t-1 bgc-secondary-l4 brc-secondary-l2 py-35 mx-n25">
              <div class="offset-md-0 col-md-12 text-nowrap">                 
  
                <button class="btn btn-info btn-bold px-4 task_id>" id="submitBtn" style="float: right" type="submit">
                  <i class="fa fa-check mr-1"></i>
                  Continue
                </button>
                <a href="/add-experience" style="float: right"  class="btn btn-outline-lightgrey btn-bgc-white btn-bold ml-2 px-4">
                  Add New Experience
                </a>             
              </div>
            </div>
          </form>

          </div>
        </div>        
        
      </div>

      {{-- @include('_section') --}}
     
    </div>

  </div>

  <script>
    $(document).ready(function(){
    
     fetch_customer_data();
    
     function fetch_customer_data(word_tense = '', soft_skill = '')
     {
      $.ajax({
       url:"find_word_tense",
       method:'GET',
       data:{word_tense:word_tense, soft_skill:soft_skill},
       dataType:'json',
       success:function(data)
       {
        $('#task_area').html(data.table_data);
        $('#total_records').text(data.total_data);
       }
      })
     }    
   
    $("#word_tense").change(function(){
      var word_tense = $(this).val();
      var soft_skill = $('#soft_skill').val();
      fetch_customer_data(word_tense,soft_skill);
     });

     $("#soft_skill").change(function(){
      var soft_skill = $(this).val();
      var word_tense = $('#word_tense').val();
      fetch_customer_data(word_tense, soft_skill);
     });

     
    });
    </script>
@endsection