
@extends('layouts.master')
@section('main_content')
<div class="no_access" style="height: 100%">
    <h1 class="text-center" style="margin:100px 0">You are not athorised of this page.</h1>
</div>
    
@endsection